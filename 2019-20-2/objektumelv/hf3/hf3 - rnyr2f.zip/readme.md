# Házi feladat
- Síkvektorok osztályának implementálása: síkvektorok összeadása, skalárszorzása, majd annak eldöntése, hogy adott síkvektorok
összege merőleges-e egy adott síkvektorra.